import React from 'react';
import BurgerMenu from './animations/BurgerMenu';
import LeftSideBar from './animations/LeftSideBar';
import './App.css';

function App() {
  return (
    <div className="App">
      <LeftSideBar />
    </div>
  );
}

export default App;
