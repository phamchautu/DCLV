# React Animation Tutorial with SCSS

This is a repository used by one of my youtube tutorial about react animation with scss. You can check it out here :

<a href="https://youtu.be/f-t4K9rJmfs">https://youtu.be/f-t4K9rJmfs</a>